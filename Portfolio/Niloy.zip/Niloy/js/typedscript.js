$(function ($) {
    // home page Typed js
    const typed = new Typed('.typed-text', {
        strings: [
			"Web Designer",
			"Envato Author",
			"Freelancer",
			"Web Developer",
			"Programmer"
		],
        typeSpeed: 40,
        backSpeed: 40,
        loop: true,
    });
});
